/*
-- Query: SELECT * FROM eproduct.products
LIMIT 0, 1000

-- Date: 2019-06-12 21:55
*/
use eproduct;
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (1,'2019-02-02','Baking Pan',10001,10,23,2);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (2,'2019-03-03','Refrigerator',10002,20,3.4,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (3,'2019-04-04','Toy Car',10003,50,2.3,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (4,'2019-02-03','Dell Laptop',10004,20,2.5,2);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (5,'2018-09-09','Bicycle',1006,24,12,3);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (6,'2009-09-09','Puzzle',1345,123,123,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (8,'2009-09-09','Folding Seat',573,123,123,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (9,'2009-02-02','Iron Press',2009,11,111,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (11,'2019-09-09','Video Game',111,2,12,2);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (12,'2009-02-02','Gas Grill',999,9,9.99,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (13,'2009-02-02','Cell Phone Tripod',100089,100,121,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (14,'2009-09-09','Door',2789,123,23,2);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (15,'2019-06-11','Wheels',1001,10,5,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (27,'2019-06-11','Printer',1001,10,5,3);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (28,'2019-02-02','Computer',10001,10,9,2);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (29,'2019-06-11','Hp Laptop',1001,10,5,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (30,'2019-06-11','Bulbs',1001,10,5,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (32,'2019-06-11','Water Bottles',1001,10,5,2);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (37,'2019-06-11','Mini Refrigerator',1001,10,5,2);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (38,'2019-06-12','Smart Watch',1001,10,5,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (41,'2019-06-12','iPhone',1001,10,5,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (42,'2019-06-12','Desktop Computer',1001,10,5,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (43,'2019-06-12','Watch',1001,10,5,1);
INSERT INTO `products` (`product_id`,`date_supplied`,`name`,`product_number`,`quantity_in_stock`,`unit_price`,`supplier_id`) VALUES (44,'2019-06-12','Cycle',1001,10,5,2);
