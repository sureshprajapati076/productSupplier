/*
-- Query: SELECT * FROM eproduct.suppliers
LIMIT 0, 1000

-- Date: 2019-06-12 21:58
*/
use eproduct;
INSERT INTO `suppliers` (`supplier_id`,`contact_phone_number`,`name`,`supplier_number`) VALUES (1,'2062476333','A Supplier',50005);
INSERT INTO `suppliers` (`supplier_id`,`contact_phone_number`,`name`,`supplier_number`) VALUES (2,'2093338909','B Supplier',60006);
INSERT INTO `suppliers` (`supplier_id`,`contact_phone_number`,`name`,`supplier_number`) VALUES (3,'8992345671','C Supplier',7007);
