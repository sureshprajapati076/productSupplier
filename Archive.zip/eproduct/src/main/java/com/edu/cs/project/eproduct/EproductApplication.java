package com.edu.cs.project.eproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EproductApplication {

	public static void main(String[] args) {
		SpringApplication.run(EproductApplication.class, args);
	}

}
