package com.edu.cs.project.eproduct.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.edu.cs.project.eproduct.model.Product;
import com.edu.cs.project.eproduct.service.ProductService;
import com.edu.cs.project.eproduct.service.SupplierService;

@Controller
public class ProductController {


	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private SupplierService supplierService;

	@RequestMapping(value="/products", method = RequestMethod.GET)
	public ModelAndView products(){		
		List<Product> products = productService.findAll();		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("products", products);
		modelAndView.setViewName("product/list");
		return modelAndView;
	}
	
	
	 @GetMapping(value = "/search")
	    public String search(Model model, String searchword) {
	    	
	    	

	        List<Product> products = productService.search(searchword);
	        model.addAttribute("products", products);

	        return "product/list";
	    }
	
	
	
	
	@RequestMapping(value="/product", method = RequestMethod.GET)
	public String create(Model model){			
		model.addAttribute("product", new Product(1001L,"Product Name Here",5.0,10,LocalDate.now()));
		model.addAttribute("suppliers",supplierService.findAll());
		return "product/edit";
	}
	
	@RequestMapping(value = "/product", method = RequestMethod.POST)
	public String edit(@Valid @ModelAttribute("product") Product product, 
			BindingResult result, Model model)  {

	
		product = productService.save(product);
		return "redirect:/products";
	}
	
	@GetMapping(value="/primeproducts")
	public String showPrimeProducts(Model model){
		
		List<Product> products=productService.findAll().stream().filter(x->x.getQuantityInStock()>=50).collect(Collectors.toList());
	
		
		
		
		model.addAttribute("products",products );
		
		
		
		
		
		return "product/list";
	}
	
	
		
	
	@RequestMapping(value="/product/{productId}", method = RequestMethod.GET)
	public String view(@PathVariable Long productId, Model model){	
		model.addAttribute("product", productService.findById(productId));
		
		model.addAttribute("suppliers",supplierService.findAll());
		
		
		
		//System.out.println(productService.findById(productId));
		return "product/edit";
	}
	
	@RequestMapping(value="/product/delete/{productId}", method = RequestMethod.GET)
	public String delete(@PathVariable Long productId, Model model){		
		productService.delete(productId);
		return "redirect:/products";
	}	

	
}