package com.edu.cs.project.eproduct.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.edu.cs.project.eproduct.model.Supplier;
import com.edu.cs.project.eproduct.service.SupplierService;

@Controller
public class SupplierController {
	@Autowired
	private SupplierService supplierService;

	@RequestMapping(value="/suppliers", method = RequestMethod.GET)
	public ModelAndView products(){		
		List<Supplier> suppliers =supplierService.findAll();		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("suppliers", suppliers);
		modelAndView.setViewName("supplier/list");
		return modelAndView;
	}

}
