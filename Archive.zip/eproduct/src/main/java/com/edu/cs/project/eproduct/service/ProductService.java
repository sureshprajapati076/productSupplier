package com.edu.cs.project.eproduct.service;

import java.util.List;
import java.util.Optional;

import com.edu.cs.project.eproduct.model.Product;



public interface ProductService {

	List<Product> findAll();

	
	Product save(Product product);


	Product findById(Long productId);
	 void delete(Long productId);
	 
	 List<Product> search(String name);

}
