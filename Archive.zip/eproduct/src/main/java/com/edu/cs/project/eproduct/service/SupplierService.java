package com.edu.cs.project.eproduct.service;

import java.util.List;

import com.edu.cs.project.eproduct.model.Supplier;

public interface SupplierService {
	List<Supplier> findAll();

}
