package com.edu.cs.project.eproduct.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.cs.project.eproduct.model.Product;
import com.edu.cs.project.eproduct.repository.ProductRepository;
import com.edu.cs.project.eproduct.service.ProductService;


@Service("productService")
public class ProductServiceImpl implements ProductService{
	@Autowired
	ProductRepository productRepository;

	@Override
	public List<Product> findAll() {
		return productRepository.findAll();
	}

	@Override
	public Product save(Product product) {
		
		return productRepository.save(product);
	}


	

	@Override
	public void delete(Long productId) {
		// TODO Auto-generated method stub
		productRepository.deleteById(productId);
		
	}

	@Override
	public Product findById(Long productId) {
		// TODO Auto-generated method stub
		return productRepository.findById(productId).orElse(null);
		
	}
	
	@Override
	public List<Product> search(String name) {
		// TODO Auto-generated method stub
		return productRepository.search(name);
	}

}
